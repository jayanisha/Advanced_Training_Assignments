package assignment_6;
import java.io.*;
import java.util.ArrayList;
public class Assgn_6_1 {
	
		public static void main (String[] args) {
			ArrayList<Integer> list = new ArrayList<>();
		list.add(1);
		list.add(2);
		list.add(3);
		list.add(4);
			
		if(list.indexOf(3)>=0)
			System.out.println("3 Sha exists in the ArrayList");
			
		else
			System.out.println("3 Sha does not exist in the ArrayList");
			
		if(list.indexOf(6)>=0)
			System.out.println("6 Jan exists in the ArrayList");
			
		else
			System.out.println("6 Jan not exist in the ArrayList");
			
		}
	}
