package assignment_7;

public class Assgn_7_2_1 extends Exception
{
    public String validname()
    {
         return ("Name is not Valid..Please ReEnter the Name");
    }
}